import java.util.*;
import java.util.ArrayList;


public class PorDispositivo extends Notificacion{
  private ArrayList<Notificacion> dipositivos;
  public PorDispositivo(String texto,boolean estado){
    super(texto,estado);
  }
  public void ingresardispositivo(Notificacion dipositivos){
    dipositivos.add(dipositivos);
  }
}
