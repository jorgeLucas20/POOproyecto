
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

class Main {
    public static void main(String[] args) throws FileNotFoundException
{
        verificar aqua = new verificar();
        
        Scanner sc = new Scanner(new File("iot_telemetry_data_new.csv"));

        ArrayList<String>dispositivos = new ArrayList<>();
             
        while(sc.hasNextLine() == true)
        {
            String separador = sc.nextLine();
          
            String part1 = separador; 

            aqua.verificarDos(part1);




          
          
        }
        sc.close();



}





}
