import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class verificar {
    ArrayList<String> textoRaw = new ArrayList<String>();

    
    verificar(){
        System.out.println("Bienvenido");
    }
    
    public void verificarDos(String cp){
        (this.textoRaw).add(cp);
        
    }

//Esta es un prueba de que toma lo datos del main
    
   /**/ 

}