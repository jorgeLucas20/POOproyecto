

public class Notificacion{
  protected String texto;
  protected boolean estado;
  public static final String separador = ",";

  public Notificacion(String texto){
    this.texto=texto;
    estado=true;
  }

  public void desactivarNotificacion()
  {
    this.estado=false;
  }





/*









*/


















}