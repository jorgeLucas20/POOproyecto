public class Sensor{
  String idSensor;
  
    
}