import java.util.*;


public class Usuario{
  public int ID;
  private String nombre;
  private String contraseña;
  public boolean estado;
  public List<Sensor> sensores=new ArrayList<>();
  public Usuario(String nombre,String contraseña,boolean estado, int ID){
    this.nombre=nombre;
    this.contraseña=contraseña;
    this.estado=estado;
    this.ID=ID;
  }

  public void anadirDispositivo(idDispositivo id){
    sensores.add(id);
  }
  
}