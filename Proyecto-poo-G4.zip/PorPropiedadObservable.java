import java.util.List;
import java.util.ArrayList;
public class PorPropiedadObservable extends Notificacion{
    String tipo; 
    public int valorMax;
    public int valorMin;
    public int prioridad;


    public PorPropiedadObservable(String texto,){
    this.texto=texto;
    estado=true;
    }

    ArrayList<String> observable = new ArrayList<>();


  


    public void crearRangos(int valorMax, int valorMin, String tipo)
    {
        this.valorMin = valorMin;
        this.valorMax = valorMax;
        this.tipo = tipo;
    }


    public String darNotificacion(string s){
      for(PropiedadObservable p:dispositivo){
        if(p.equals(s)){
          if(valor>valorMax){
          return "Peligro"
        }
        if(valor<valorMax && valor >valorMin){
          return "Moderado"
        }
        else{
          return "Bajo"
        }

        }
        
      }
    }





















}