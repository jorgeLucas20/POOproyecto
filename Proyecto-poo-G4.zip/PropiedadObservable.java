public class PropiedadObservable{
  
}