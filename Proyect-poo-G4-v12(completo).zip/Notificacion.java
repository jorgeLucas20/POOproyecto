public abstract class Notificacion {

  protected boolean estado;
  // public static final String separador = ",";
  /* se ve si las notificaciones estan activas por un booleano*/
  public Notificacion(boolean estado) {
    estado = true;
  }

/*Con esto se desactiva las notificaciones , se ve simple pero hace su trabajo :D*/
  public void desactivarNotificacion() {
    this.estado = false;
  }

}