public class PropiedadObservable{
  private float valor; 
  private String tipo;

/* crea un constructor*/
  public PropiedadObservable(float valor,String tipo){
    this.valor=valor;
    this.tipo=tipo;
  }
/* retornas el valor*/
  public float getValor(){
    return this.valor;
  }
}