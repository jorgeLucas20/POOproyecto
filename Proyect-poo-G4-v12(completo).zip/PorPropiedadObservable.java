import java.util.*;




public class PorPropiedadObservable extends Notificacion{

    private PropiedadObservable observacion; 
    public float valorMax;
    public float valorInmedio;    
    public float valorMin;  
    public int prioridad;   
    boolean estado;
    
    ArrayList<PropiedadObservable> observable = new ArrayList<>();
   

    
    public void crearRangos(float valorMax,float valorMin)
    {
        this.valorMin = valorMin;
        this.valorMax = valorMax;
    }








    public PorPropiedadObservable(PropiedadObservable observacion,boolean estado){
    super(estado);
    this.observacion=observacion;
    this.prioridad=0;
    }


    


   

    public void SubirPrioridad(){
      prioridad+=1;
    }




}