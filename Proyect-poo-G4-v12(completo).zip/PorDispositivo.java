import java.util.*;



public class PorDispositivo extends Notificacion{
  private boolean estado;

  private ArrayList<Sensor> dispositivos=new ArrayList<>();

  /* se revisa el estado por dispositivo con true como inicial*/
  public PorDispositivo(boolean estado){
    super(estado);
  }
  /* añade el dispositivo por medio del array sensor*/
  public void ingresardispositivo(Sensor dispositivo){
    dispositivos.add(dispositivo);
  }
  /* en este metodo se llama al dispositivo aaray y se lo recorre para luego igualarlo para aumentar el valor si no no existe*/
  public String DarNotificacion(Sensor dispositivo,PropiedadObservable observacion){
  String valor="";
    for (Sensor s:dispositivos){
      
      if(s.getidSensor().equals(dispositivo.getidSensor())){
        valor+="";/*deberia llamar al metodo de notificaion oor propiedado observable*/
        
      }
      else{
        valor+="No existe el dispositivo";
      }
      
    }
    return valor;

  }
  

}

