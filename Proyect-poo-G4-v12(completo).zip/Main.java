/*Mi compañero afirmo que solo uno deberia subir y como lo hicimos en IDE's independientes de cada uno mantuvimos la idea*/
/* jorge lucas benavides
Xavier Cobos
Robinson Jacome*/
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

class Main {
  static Scanner ruby = new Scanner(System.in);/*escaner para ingresar los id usuario del registro y otros array*/

  public static void main(String[] args) throws FileNotFoundException {
    
    Sistema base = new Sistema();
    // System.out.println(base.getDispostitivos().toString());
    // System.out.println(base.lines.get(1));
    crearNuevoUsuario(base);

  }


  /*
  Menu de registro
  */
  public static void crearNuevoUsuario(Sistema sys) {
    /*se crea el menu y se lo recorre con un casa dependiendo de la seleccion del usuario */
    String opcionn = "";
    System.out.println(
        "\nBienvenido al sistema de notificaciones multifuncional que sirve implicitamente para crear notificaciones a su gusto, con el simple hecho de registrarse  ya podra acceder a estas caracteristicas\n----------------------------------------\nPrimero creemos una cuenta o en su caso iniciar sesion :D\n");
    do {
      System.out.println("1) Registrar\n2) Iniciar sesion\n3) Nel loco, me la saco :3\n");
      opcionn = ruby.nextLine();
      switch (opcionn) {
        case "1":
          System.out.println("Registrate con su propio ID\n");
          String IDnew = ruby.nextLine();
          Usuario usr = new Usuario(IDnew);
          sys.agregarUsuario(usr);
          break;

        case "2":
          System.out.println("Ingrese su nombre usuario\n");
          String id = ruby.nextLine();
          Usuario user = new Usuario(id);
          for (Usuario U : sys.getUsuarios()) {
            if (user.equals(U)) {
              System.out.println("Inicio de sesion correcto :D\n");
              menuInicioSesion(U, sys);
              break;
            } else {
              System.out.println("no existe ese usuario\n");
              break;
            }
          }
          break;
        case "3":
          System.out.println("Adios");
          break;
        default:
          System.out.println("Opcion invalida");
          break;
      }
    } while (!opcionn.equals("3"));
  }

/*
Menu de notificaciones
*/

  public static void menuInicioSesion(Usuario u, Sistema sys) {
    String opcion = "";
    System.out.println("Menu principal");
    do {
      System.out.println("1. Programar notificaciones");
      System.out.println("2. Generar notificaciones");
      System.out.println("3. Cerrar Sesion");
      System.out.print("Ingrese opcion: ");
      opcion = ruby.nextLine();

      switch (opcion) {
        case "1":
          u.programarNotificaciones(sys);
          break;
        case "2":
          u.generarNotificaciones(sys);
          break;
        case "3":
          System.out.println("Adios");
          break;
        default:
          System.out.println("opcion invalida");
          break;
      }
    } while (!opcion.equals("3"));
  }

}
