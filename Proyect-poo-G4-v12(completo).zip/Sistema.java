import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*Lectura del CSV para obtenes los Id de los dispositivos*/

public class Sistema {
    private ArrayList<String> dispositivosAdmitidos;//Se almacenaran en este arreglo
    private ArrayList<Usuario> usuarios;//los susuarios que se vayan registrando se almacenaran en este arreglo
    public BufferedReader reader;
    private List<String> lines;


    /*Se usa throws para usar el metodo hasta que se produzca un error de excepcion*/
    public Sistema() throws FileNotFoundException {
        usuarios = new ArrayList<>();
        reader = new BufferedReader(new FileReader("iot_telemetry_data_new.csv"));
        dispositivosAdmitidos = new ArrayList<>();
        lines = new ArrayList<>();
        String line = null;
    /*Asi como el throws usamos try por si se produce errores en tiempo de ejecucion*/
        try {
            while ((line = reader.readLine()) != null) {
                lines.add(line);/*lee cada linea y lo añade a la lista lines*/
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (String linea : lines) {
            String[] fila = linea.split(",");
            if (!dispositivosAdmitidos.contains(fila[1]) && !fila[1].equals("\"device\""))
                dispositivosAdmitidos.add(fila[1]);
        }

    }


    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    /*Usamos este metodo para añadir los ususarios registrados en el arreglo usuarios*/
    public void agregarUsuario(Usuario u) {
        if (!usuarios.contains(u)) {
            usuarios.add(u);
        } else {
            System.out.println("Usuario ya existe");
        }
    }
    /* este metodo retorna dispositivos que pasaron por el testing, vienen directamente del array*/
    public ArrayList<String> getDispostitivos() {
        return dispositivosAdmitidos;
    }
    /* este metodo retorna los lines que pasaron por el testong, y las recolecta en una list*/
    public List<String> getLines() {
        return lines;
    }






}
