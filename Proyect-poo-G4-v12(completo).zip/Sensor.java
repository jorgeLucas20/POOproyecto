import java.util.*;

public class Sensor {
  String idSensor;
/* crea un constructor*/
  public Sensor(String idSensor) {
    this.idSensor = idSensor;
  }

  /* retornas el valor*/
  public String getidSensor() {
    return idSensor;
  }

}