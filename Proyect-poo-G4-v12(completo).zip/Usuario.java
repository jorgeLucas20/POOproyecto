import java.util.*;
import java.util.stream.Collectors;

public class Usuario {

  private String id;
  public List<Sensor> sensores;
  ArrayList<PropiedadObservable> observaciones;
  ArrayList<Notificacion> notificaciones;

  

  public Usuario(String id) {
    this.id = id;
    sensores = new ArrayList<>();
    notificaciones = new ArrayList<>();
  }



  public String getId() {
    return id;
  }


/*Anade el dispositivo al array sensores para tenerlos disponibles*/
  public void anadirDispositivo(Sensor dispositivo) {
    sensores.add(dispositivo);
  }

/*recibe los dispositivos del csv y sus valores para diseñar la snotificaciones*/



  public void programarNotificaciones(Sistema sys) {
    Scanner sc = new Scanner(System.in);
    String opc = "";
    do {
      System.out.println("1. Por propiedad observable");
      System.out.println("2. Por dispositivo");
      System.out.println("3. Salir");
      opc = sc.nextLine();
      switch (opc) {
        case "1":
        System.out.println("Ingrese la propiedad observable que desea notificar");
        String op = sc.nextLine();

        switch(op)
        {
            case "temp":
            System.out.print("");
        }

        




        case "2":
          List<String> dispositivos = sys.getDispostitivos().stream().collect(Collectors.toList());

          for (String device : dispositivos) {
            int indice = dispositivos.indexOf(device) + 1;
            System.out.println(indice + ". " + device);
          }

          boolean validacion = false;
          int opc2 = 0;

          while (!validacion) {
            System.out.println("Escoja un dispositivo: ");
            System.out.println("0. Salir");
            opc2 = Integer.parseInt(sc.nextLine());
            if (opc2 == (int) opc2 && opc2 > 0 && opc2 <= dispositivos.size()) {
              validacion = true;
            } else if (opc2 == 0) {
              validacion = true;
            } else {
              System.out.println("Entrada invalida, vuelva a ingresar! ");
            }
          }

          if (opc2 == 0) {
            System.out.println("Ha decido volver al menu principal");
            System.out.println(" "); // espacio
          } else {
            sensores.add(new Sensor(dispositivos.get(opc2 - 1)));
            System.out.println("Dispositivo agregado");
          }
        case "3":
          System.out.println("Adios");
          break;
        default:
          System.out.println("Opcion invalida");
          break;
      }
    } while (!opc.equals("3"));

  }
/*Generar notificaciones para el usuario*/
  public void generarNotificaciones(Sistema sys) {
    if (sensores.isEmpty()) {
      System.out.println("Imprimiendo");
    } else {
      for (Sensor s : sensores) {
        for (String linea : sys.getLines()) {
          String[] fila = linea.split(",");
          if (fila[1].equals(s.getidSensor())) {

          }
        }
      }
    }

  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof Usuario) {

      Usuario other = (Usuario) obj;

      if (id.equals(other.getId()))
        return true;
    }

    return false;
  }


}